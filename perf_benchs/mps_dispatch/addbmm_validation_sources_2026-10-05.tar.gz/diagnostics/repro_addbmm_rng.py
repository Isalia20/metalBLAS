import json
import torch

cases = [('nn', 3, 32, 32, 32), ('nn', 16, 64, 64, 128),
         ('tt', 3, 31, 49, 8193), ('nn', 3, 256, 256, 256),
         ('nt', 8, 128, 96, 256), ('tn', 3, 1, 64, 4096),
         ('nt', 3, 4096, 8, 256), ('tn', 3, 8, 4096, 256)]
torch.manual_seed(5197)
result = {'torch': torch.__version__, 'seed': 5197, 'nonfinite_inputs': []}
for name, dtype in [('f32', torch.float32), ('f16', torch.float16), ('bf16', torch.bfloat16)]:
    for layout, batch, m, n, k in cases:
        shapes = [(batch, k, m) if layout[0] == 't' else (batch, m, k),
                  (batch, n, k) if layout[1] == 't' else (batch, k, n), (n,)]
        for label, shape in zip(('a', 'b', 'bias'), shapes):
            x = torch.randn(shape, device='mps', dtype=dtype).cpu()
            bad = ~torch.isfinite(x)
            if bad.any():
                result['nonfinite_inputs'].append({'dtype': name, 'layout': layout, 'shape': [batch, m, n, k],
                    'input': label, 'indices': bad.nonzero().tolist(), 'values': x[bad].float().tolist()})
print(json.dumps(result, indent=2))
