"""Record nonbroadcast batched inputs exactly as in the public benchmark."""
import ctypes
from dataclasses import asdict
import gzip
import hashlib
import json
import os
from pathlib import Path
import platform
import sys

sys.path.insert(0, str(Path.cwd()))
from tools.mps_trace_sweep import build_tracer
from tools.mps_trace_epilogue import parse_trace

root = Path('/tmp/metalblas-mps-recovery')
raw = root / 'a18_batched_layout_trace.jsonl'
os.environ['MBTRACE_OUT'] = str(raw)
os.environ['MBTRACE_DAG'] = '1'
os.environ['MPS_LOG_INFO'] = '1'
os.environ['MPS_LOG_AUTO_TUNE'] = '1'
lib = ctypes.CDLL(build_tracer())
lib.mbtrace_mark.argtypes = [ctypes.c_char_p]
import torch
from metalblas.mps_heuristics import device_info

torch.manual_seed(9840)
for dtype, dt in [('f16', torch.float16), ('bf16', torch.bfloat16)]:
    for layout in ('nn', 'nt', 'tn', 'tt'):
        m, n, k, batch = 31, 49, 8193, 3
        a = torch.randn((batch, k, m) if layout[0] == 't' else (batch, m, k)).to(device='mps', dtype=dt)
        b = torch.randn((batch, n, k) if layout[1] == 't' else (batch, k, n)).to(device='mps', dtype=dt)
        if layout[0] == 't': a = a.transpose(-1, -2)
        if layout[1] == 't': b = b.transpose(-1, -2)
        bias = torch.randn(n).to(device='mps', dtype=dt)
        for op in ('bmm', 'addbmm'):
            case = dict(dtype=dtype, layout=layout, shape=[m, n, k], batch=batch, op=op,
                        alpha=1., beta=1. if op == 'addbmm' else 0., broadcast=False)
            torch.mps.synchronize()
            print('CASE', json.dumps(case), file=sys.stderr, flush=True)
            lib.mbtrace_mark(('begin ' + json.dumps(case)).encode())
            out = torch.bmm(a, b) if op == 'bmm' else torch.addbmm(bias, a, b)
            torch.mps.synchronize()
            lib.mbtrace_mark(b'end')
result = dict(device=asdict(device_info()), torch=torch.__version__, macos=platform.mac_ver()[0],
              tool_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              cases=parse_trace(raw))
(root / 'a18_batched_layout_trace.json.gz').write_bytes(
    gzip.compress((json.dumps(result, separators=(',', ':'))+'\n').encode(), mtime=0))
