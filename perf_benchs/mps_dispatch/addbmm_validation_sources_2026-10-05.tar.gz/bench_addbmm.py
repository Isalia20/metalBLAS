"""Validation-only addbmm comparison; no timings feed the current dispatcher."""
import argparse
import dataclasses
import gzip
import hashlib
import json
from pathlib import Path
import platform
import statistics
import sys

sys.path.insert(0, str(Path.cwd()))
import torch
import metalblas
from metalblas.mps_heuristics import device_info
from metalblas.mps_reduction import reduction_plans
from bench.bench_mps_dispatch import load_baseline, source_hashes, selected_plan, elapsed


def cpu_error(value, expected, atol, rtol):
    error = (value.cpu().double() - expected).abs()
    allowed = atol + rtol * expected.abs()
    return {'max_error': error.max().item(), 'outside_tolerance': int((error > allowed).sum()),
            'rms_error': error.square().mean().sqrt().item()}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--baseline-root', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    baseline = load_baseline(args.baseline_root)
    major = int(platform.mac_ver()[0].split('.')[0])
    dev = device_info()
    result = {'device': dataclasses.asdict(dev), 'macos': platform.mac_ver()[0],
              'torch': torch.__version__, 'iterations': 40, 'trials': 5, 'warmup': 10,
              'method': 'Rotated/reversed interleaved synchronized wall-clock medians; public addbmm with allocation and planning',
              'alpha': 1., 'beta': 1., 'seed': 5197,
              'input_generation': 'CPU float32 normal samples converted to each dtype on MPS; finite and unchanged inputs required',
              'source_sha256': source_hashes(Path.cwd()),
              'baseline_source_sha256': source_hashes(args.baseline_root),
              'baseline_environment': {'METALBLAS_AUTOTUNE': '1', 'METALBLAS_TILE_POLICY': 'legacy'},
              'benchmark_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              'baseline_helper_sha256': hashlib.sha256(Path('bench/bench_mps_dispatch.py').read_bytes()).hexdigest(),
              'cpu_reference_note': 'Unrounded float64 matmuls summed before the final dtype conversion; this differs from MPSGraph intermediate rounding',
              'cases': []}
    cases = [('nn', 3, 32, 32, 32), ('nn', 16, 64, 64, 128),
             ('tt', 3, 31, 49, 8193), ('nn', 3, 256, 256, 256),
             ('nt', 8, 128, 96, 256), ('tn', 3, 1, 64, 4096),
             ('nt', 3, 4096, 8, 256), ('tn', 3, 8, 4096, 256)]
    torch.manual_seed(5197)
    for name, dtype in [('f32', torch.float32), ('f16', torch.float16), ('bf16', torch.bfloat16)]:
        for layout, batch, m, n, k in cases:
            a = torch.randn((batch, k, m) if layout[0] == 't' else (batch, m, k)).to(device='mps', dtype=dtype)
            b = torch.randn((batch, n, k) if layout[1] == 't' else (batch, k, n)).to(device='mps', dtype=dtype)
            if layout[0] == 't': a = a.transpose(-1, -2)
            if layout[1] == 't': b = b.transpose(-1, -2)
            bias = torch.randn(n).to(device='mps', dtype=dtype)
            initial_inputs = [x.cpu() for x in (a, b, bias)]
            assert all(torch.isfinite(x).all() for x in initial_inputs)
            fns = {'mps': lambda: torch.addbmm(bias, a, b),
                   'static': lambda: metalblas.addbmm(bias, a, b),
                   'autotuned': lambda: baseline.addbmm(bias, a, b)}
            print(name, layout, (batch, m, n, k), flush=True)
            for fn in fns.values():
                for _ in range(10): fn()
            assert all(torch.equal(x.cpu(), original) for x, original in zip((a, b, bias), initial_inputs)), 'Warmup modified an input'
            outputs = {label: fn().cpu() for label, fn in fns.items()}
            assert all(torch.isfinite(x).all() for x in outputs.values()), 'Nonfinite output from finite inputs'
            expected = ((initial_inputs[0].double() @ initial_inputs[1].double()).sum(0)
                        + initial_inputs[2].double()).to(dtype).double()
            atol, rtol = {torch.float32: (1e-3, 2e-5), torch.float16: (2e-3, 1e-3),
                          torch.bfloat16: (2e-2, 8e-3)}[dtype]
            comparisons = {}
            for label, output in outputs.items():
                comparisons[label] = {'bitwise_mps': torch.equal(output, outputs['mps']),
                                      'close_mps': torch.allclose(output.float(), outputs['mps'].float(), atol=atol, rtol=rtol),
                                      'max_error_mps': (output.float() - outputs['mps'].float()).abs().max().item(),
                                      'float64_reference': cpu_error(output, expected, atol, rtol)}
            times = {label: [] for label in fns}
            labels = list(fns)
            for trial in range(5):
                order = labels[trial % 3:] + labels[:trial % 3]
                for label in order[::1 if trial % 2 == 0 else -1]:
                    times[label].append(elapsed(fns[label], 40))
            assert all(torch.equal(x.cpu(), original) for x, original in zip((a, b, bias), initial_inputs)), 'Timed runs modified an input'
            medians = {label: statistics.median(values) for label, values in times.items()}
            row = {'dtype': name, 'layout': layout, 'shape': [m, n, k], 'batch': batch,
                   'matmul_plan': selected_plan(a, b),
                   'reduction_plans': [dataclasses.asdict(p) for p in reduction_plans(m, n, batch, dev=dev, macos_major=major)],
                   'outputs': comparisons, 'tolerance': {'atol': atol, 'rtol': rtol},
                   'trials_us': times, 'median_us': medians,
                   'speedup_mps': medians['mps'] / medians['static'],
                   'speedup_autotuned': medians['autotuned'] / medians['static']}
            result['cases'].append(row)
            args.out.write_bytes(gzip.compress((json.dumps(result, separators=(',', ':')) + '\n').encode(), mtime=0))
            print('  MPS %.3fx; old %.3fx; equal MPS %s' % (row['speedup_mps'], row['speedup_autotuned'], comparisons['static']['bitwise_mps']), flush=True)


if __name__ == '__main__':
    main()
