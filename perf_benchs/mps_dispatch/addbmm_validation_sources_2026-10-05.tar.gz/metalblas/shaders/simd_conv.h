// simd_conv.h - Portable implicit-GEMM conv on simdgroup_matrix (Metal 3; pre-macOS 26).
#ifdef MB_BUILD_SIMD_CONV
#include <metal_stdlib>
#include <metal_simdgroup>
#include <metal_simdgroup_matrix>

using namespace metal;

#define IN_T   __IN_T__
#define ACC_T  __ACC_T__
#define OUT_T  __OUT_T__
#define BO     __BO__
#define BW     __BW__
#define BWL    __BWL__
#define BH     __BH__
#define WM     __WM__
#define WN     __WN__
#define BK     __BK__
#define KH     __KH__
#define KW     __KW__
#define SX     __SX__
#define SY     __SY__
#define DX     __DX__
#define DY     __DY__
#define AVEC   __AVEC__
#define BVEC   __BVEC__

#ifndef BIAS
#define BIAS 0
#endif
#ifndef D_NCHW
#define D_NCHW 0
#endif
#ifndef GROUPED
#define GROUPED 0
#endif
#ifndef CONV3D
#define CONV3D 0
#endif
#ifndef KD
#define KD 1
#endif
#ifndef SZ
#define SZ 1
#endif
#ifndef DZ
#define DZ 1
#endif

// GEMM view: M = BW*BH output pixels, N = BO out-channels, K = taps x channels.
#define BM       (BW * BH)
#define SG_SIZE  32
#define WARPS    (WM * WN)
#define TGP_SIZE (WARPS * SG_SIZE)

constant constexpr int WT_M = BM / WM;
constant constexpr int WT_N = BO / WN;
constant constexpr int TM   = WT_M / 8;
constant constexpr int TN   = WT_N / 8;

constant constexpr int PAD_TG  = 16 / sizeof(IN_T);
constant constexpr int LDA_TGP = BK + PAD_TG;
constant constexpr int LDB_TGP = BO + PAD_TG;

constant constexpr int VEC        = 16 / sizeof(IN_T);
constant constexpr int A_TCOLS    = BK / VEC;
constant constexpr int A_ROW_STEP = TGP_SIZE / A_TCOLS;
constant constexpr int B_TCOLS    = BO / VEC;
constant constexpr int B_ROW_STEP = TGP_SIZE / B_TCOLS;

struct alignas(16) VecF { IN_T v[VEC]; };

static_assert(BM % (8 * WM) == 0, "BM must be a multiple of 8*WM");
static_assert(BO % (8 * WN) == 0, "BO must be a multiple of 8*WN");
static_assert(BK % 8 == 0 && BK % VEC == 0, "BK must be a multiple of 8 and VEC");
static_assert(BO % VEC == 0, "BO must be a multiple of VEC");
static_assert((BW & (BW - 1)) == 0, "BW must be a power of two");

struct MBConvDims {
    int C, H, W, O;
    int HO, WO, NB;
    int PADX, PADY;
    int CG, OG, OGT;
    int D, DO, PADZ;
};

kernel void simd_conv(
    device const IN_T  *act  [[buffer(0)]],   // NHWC (N,[D,]H,W,C)
    device const IN_T  *wts  [[buffer(1)]],   // HWIO ([KD,]KH,KW,CG,O)
    device       OUT_T *dst  [[buffer(2)]],
    constant MBConvDims& gP  [[buffer(3)]],
#if BIAS
    device const OUT_T *bias [[buffer(4)]],
#endif
    uint3 tgid [[threadgroup_position_in_grid]],
    uint  sgid [[simdgroup_index_in_threadgroup]],
    uint  lane [[thread_index_in_simdgroup]])
{
    int h_tiles = (gP.HO + BH - 1) / BH;
#if GROUPED
    int g      = int(tgid.x) / gP.OGT;
    int o_off  = (int(tgid.x) % gP.OGT) * BO + g * gP.OG;
    int o_end  = g * gP.OG + gP.OG;
    int c_base = g * gP.CG;
#else
    int o_off  = int(tgid.x) * BO;
    int o_end  = gP.O;
    int c_base = 0;
#endif
    int wo_off = int(tgid.y) * BW;
    int zi     = int(tgid.z);
    int ho_off = (zi % h_tiles) * BH;
    zi /= h_tiles;
#if CONV3D
    int dd = zi % gP.DO;
    int nb = zi / gP.DO;
#else
    int nb = zi;
#endif

    threadgroup IN_T As[BM * LDA_TGP];
    threadgroup IN_T Bs[BK * LDB_TGP];
    int tid = int(sgid) * SG_SIZE + int(lane);

    int warp_m = (int(sgid) / WN) * WT_M;
    int warp_n = (int(sgid) % WN) * WT_N;

    simdgroup_matrix<ACC_T, 8, 8> Cfrag[TM][TN];
    #pragma unroll
    for (int i = 0; i < TM; ++i)
        #pragma unroll
        for (int j = 0; j < TN; ++j)
            Cfrag[i][j] = simdgroup_matrix<ACC_T, 8, 8>(0);

    int64_t plane = (int64_t)gP.H * gP.W * gP.C;
    device const IN_T *actn = act + (int64_t)nb * gP.D * plane;
    int cg = gP.CG;
    int kchunks = (cg + BK - 1) / BK;

    int a_r0 = tid / A_TCOLS;
    int a_c0 = (tid % A_TCOLS) * VEC;
    int b_r0 = tid / B_TCOLS;
    int b_c0 = (tid % B_TCOLS) * VEC;

#if CONV3D
    for (int kd = 0; kd < KD; ++kd) {
        int di = dd * SZ - gP.PADZ + kd * DZ;
        if (di < 0 || di >= gP.D) continue;          // tg-uniform: barriers stay in sync
        device const IN_T *actd = actn + (int64_t)di * plane;
#else
    {
        constexpr int kd = 0;
        device const IN_T *actd = actn;
#endif
        for (int kh = 0; kh < KH; ++kh) {
            for (int kw = 0; kw < KW; ++kw) {
                device const IN_T *wtap =
                    wts + ((int64_t)((kd * KH + kh) * KW + kw) * cg) * gP.O;
                for (int kc = 0; kc < kchunks; ++kc) {
                    int c0 = kc * BK;
                    int krem = min(BK, cg - c0);
                    threadgroup_barrier(mem_flags::mem_threadgroup);
                    // A tile: each row is one output pixel's channel slice at this tap.
                    #pragma unroll
                    for (int rr = 0; rr < BM; rr += A_ROW_STEP) {
                        int r = a_r0 + rr;
                        if (r >= BM) break;
                        int ix = (wo_off + (r & (BW - 1))) * SX - gP.PADX + kw * DX;
                        int iy = (ho_off + (r >> BWL)) * SY - gP.PADY + kh * DY;
                        VecF v;
                        if (ix >= 0 && ix < gP.W && iy >= 0 && iy < gP.H) {
                            device const IN_T *src = actd +
                                ((int64_t)iy * gP.W + ix) * gP.C + c_base + c0 + a_c0;
                            if (AVEC && a_c0 + VEC <= krem) {
                                v = *((device const VecF*)src);
                            } else {
                                #pragma unroll
                                for (int i = 0; i < VEC; ++i)
                                    v.v[i] = (a_c0 + i < krem) ? src[i] : (IN_T)0;
                            }
                        } else {
                            #pragma unroll
                            for (int i = 0; i < VEC; ++i) v.v[i] = (IN_T)0;
                        }
                        *((threadgroup VecF*)(&As[r * LDA_TGP + a_c0])) = v;
                    }
                    // B tile: weight slab, rows = channels, cols = out-channels.
                    #pragma unroll
                    for (int rr = 0; rr < BK; rr += B_ROW_STEP) {
                        int r = b_r0 + rr;
                        if (r >= BK) break;
                        int o0 = o_off + b_c0;
                        VecF v;
                        if (r < krem) {
                            device const IN_T *src = wtap + (int64_t)(c0 + r) * gP.O + o0;
                            if (BVEC && o0 + VEC <= gP.O) {
                                v = *((device const VecF*)src);
                            } else {
                                #pragma unroll
                                for (int i = 0; i < VEC; ++i)
                                    v.v[i] = (o0 + i < gP.O) ? src[i] : (IN_T)0;
                            }
                        } else {
                            #pragma unroll
                            for (int i = 0; i < VEC; ++i) v.v[i] = (IN_T)0;
                        }
                        *((threadgroup VecF*)(&Bs[r * LDB_TGP + b_c0])) = v;
                    }
                    threadgroup_barrier(mem_flags::mem_threadgroup);

                    #pragma unroll
                    for (int kk = 0; kk < BK; kk += 8) {
                        simdgroup_matrix<IN_T, 8, 8> Afrag[TM];
                        simdgroup_matrix<IN_T, 8, 8> Bfrag[TN];
                        #pragma unroll
                        for (int i = 0; i < TM; ++i)
                            simdgroup_load(Afrag[i],
                                           &As[(warp_m + i * 8) * LDA_TGP + kk],
                                           LDA_TGP);
                        #pragma unroll
                        for (int j = 0; j < TN; ++j)
                            simdgroup_load(Bfrag[j],
                                           &Bs[kk * LDB_TGP + warp_n + j * 8],
                                           LDB_TGP);
                        #pragma unroll
                        for (int i = 0; i < TM; ++i)
                            #pragma unroll
                            for (int j = 0; j < TN; ++j)
                                simdgroup_multiply_accumulate(Cfrag[i][j], Afrag[i], Bfrag[j], Cfrag[i][j]);
                    }
                }
            }
        }
    }

#if CONV3D
  #if D_NCHW
    #define MB_DIDX(o) (((((int64_t)nb * gP.O + (o)) * gP.DO + dd) * gP.HO + y) * gP.WO + x)
  #else
    #define MB_DIDX(o) (((((int64_t)nb * gP.DO + dd) * gP.HO + y) * gP.WO + x) * gP.O + (o))
  #endif
#else
  #if D_NCHW
    #define MB_DIDX(o) ((((int64_t)nb * gP.O + (o)) * gP.HO + y) * gP.WO + x)
  #else
    #define MB_DIDX(o) ((((int64_t)nb * gP.HO + y) * gP.WO + x) * gP.O + (o))
  #endif
#endif

    // (row, col) each lane owns within an 8x8 simdgroup_matrix.
    const short qid = lane / 4;
    const short fm  = (qid & 4) + ((lane / 2) % 4);
    const short fn  = (qid & 2) * 2 + (lane % 2) * 2;

    #pragma unroll
    for (int i = 0; i < TM; ++i) {
        int r = warp_m + i * 8 + fm;
        int x = wo_off + (r & (BW - 1));
        int y = ho_off + (r >> BWL);
        if (x >= gP.WO || y >= gP.HO) continue;
        #pragma unroll
        for (int j = 0; j < TN; ++j) {
            int o = o_off + warp_n + j * 8 + fn;
            ACC_T te0 = Cfrag[i][j].thread_elements()[0];
            ACC_T te1 = Cfrag[i][j].thread_elements()[1];
#if BIAS
            if (o < o_end)     te0 += (ACC_T)bias[o];
            if (o + 1 < o_end) te1 += (ACC_T)bias[o + 1];
#endif
            if (o < o_end)     dst[MB_DIDX(o)]     = (OUT_T)te0;
            if (o + 1 < o_end) dst[MB_DIDX(o + 1)] = (OUT_T)te1;
        }
    }
}
#endif  // MB_BUILD_SIMD_CONV
