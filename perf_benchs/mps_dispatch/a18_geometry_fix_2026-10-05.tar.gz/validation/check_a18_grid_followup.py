"""Check the isolated A18 geometry correction against encoder captures."""
from contextlib import ExitStack
import gzip
import hashlib
import json
from pathlib import Path
import sys
from unittest.mock import patch

sys.path.insert(0, str(Path.cwd()))
import torch
import metalblas
from metalblas import float_dispatch, mps_heuristics
from tools.mps_graph_reference import addmm as graph_addmm

root = Path('/tmp/metalblas-mps-recovery')
capture = json.loads(gzip.decompress((root / 'a18_batched_layout_trace_with_params.json.gz').read_bytes()))
results = []
torch.manual_seed(7641)
with ExitStack() as stack:
    stack.enter_context(patch.object(float_dispatch, '_TILE_POLICY', 'mps'))
    for name in ('_gemm_plan', '_gemm_trans_plan', '_bmm_plan', '_fastest'):
        stack.enter_context(patch.object(float_dispatch, name,
            side_effect=AssertionError(f'Source dispatch reached {name}')))
    for row in capture['cases']:
        case = row['case']
        dtype = {'f16': torch.float16, 'bf16': torch.bfloat16}[case['dtype']]
        m, n, k = case['shape']
        batch = case['batch']
        ta, tb = [p == 't' for p in case['layout']]
        key = mps_heuristics.make_key(m, n, k, ta, tb, mps_heuristics.DTYPE_CODE[dtype], batch)
        assert tuple(key) == tuple(row['mps_key']), (case, key, row['mps_key'])
        plan = mps_heuristics.plan(m, n, k, ta, tb, dtype, batch)
        assert plan.params == tuple(row['mps_params']), (case, plan.params, row['mps_params'])
        fn, threads, group, dims = float_dispatch._a18_launch(dtype, m, n, k, plan.params, ta, tb, batch=batch)
        actual = next(d for d in row['dispatches'] if d['kernel'] == 'gemm_a18')
        grid = tuple(t // g for t, g in zip(threads, group))
        assert all(t % g == 0 for t, g in zip(threads, group))
        assert grid == tuple(actual['grid']), (case, grid, actual['grid'])
        assert group == tuple(actual['tg']), (case, group, actual['tg'])
        assert fn.static_thread_group_memory_length == actual['staticTG'] + sum(actual['tgmem'].values())
        a = torch.randn((batch, k, m) if ta else (batch, m, k)).to(device='mps', dtype=dtype)
        b = torch.randn((batch, n, k) if tb else (batch, k, n)).to(device='mps', dtype=dtype)
        if ta:
            a = a.transpose(-1, -2)
        if tb:
            b = b.transpose(-1, -2)
        if case['op'] == 'addbmm':
            bias = torch.randn(n).to(device='mps', dtype=dtype)
            got = metalblas.addbmm(bias, a, b).cpu()
            expected = graph_addmm(bias, a, b, reduce_batch=True)
        else:
            got = metalblas.bmm(a, b).cpu()
            expected = torch.bmm(a, b).cpu()
        assert bool(torch.isfinite(got).all()) and bool(torch.isfinite(expected).all())
        torch.testing.assert_close(got, expected, atol=0, rtol=0)
        results.append(dict(case=case, grid=grid, group=group, bitwise=True,
                            static_threadgroup_memory=fn.static_thread_group_memory_length,
                            dimensions=dims))
        print(case, 'key, 17 parameters, grid, group, memory and output match', flush=True)
summary = dict(source_root=str(Path.cwd()),
               launcher_sha256=hashlib.sha256(Path(float_dispatch.__file__).read_bytes()).hexdigest(),
               capture_sha256=hashlib.sha256((root / 'a18_batched_layout_trace_with_params.json.gz').read_bytes()).hexdigest(),
               results=results)
(root / 'a18_grid_followup_results.json').write_text(json.dumps(summary, indent=2) + '\n')
print(f'PASS: {len(results)} dispatches and GPU outputs')
